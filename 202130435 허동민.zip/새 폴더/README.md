# 허동민
## 202130435    
### 학생 정보
이름: 허동민, 학번: 202130435, 파일 경로: /src/app/components/UserInfo.tsx